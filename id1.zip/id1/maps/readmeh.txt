


.:quake single player map (r v2)
.:::::: (q1) 



Instructions / INSTALLATION 

Unzip .bsp to quake/id1/maps directory

To start, in quake`s console type: map spd



record a demo and send me (use dzip please  http://www.planetquake.com/sda/dzip/)


:::::::::::::::::::::::2003

Autor: Speedy
	 www.planetquake.com/speedy
	 speeds@bk.ru
	 ICQ 68154481	


testers: Moaltz, Aguirre